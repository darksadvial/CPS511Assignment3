Karl Dadivas
500345383
CPS 511 Assignment 3

To run program, compile main.c and run project 

Only file modified was main.c given from the A1 skeleton code named mainA3.c

Requirements met:
Full A1 movement drone 
Building and ground collision
Drone prints destroyed and spawned at location
Torpedo fires, and destroys second drone
Second drone with movement 
Camera implemented

Note Camera does not have zoom or tilt feature, although located on underside of drone 